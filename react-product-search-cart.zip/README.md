# React Product Search & Cart

A React practice mini-project built during React feature-development preparation.

## Features

- Product search by name
- Case-insensitive search
- In-stock filtering
- Add products to cart
- Prevent duplicate cart items
- Remove products from cart
- Cart item count
- Product and cart rendering with `map()`
- Filtering with `filter()`
- Duplicate checking with `some()`
- Immutable state updates using the spread operator
- Controlled input and checkbox
- React `useState`
- React event handling
- JSX and list keys

## React concepts practiced

- Components
- JSX
- `useState`
- Events
- Controlled forms
- Conditional filtering
- Lists and keys
- State immutability
- JavaScript array methods

## Next

Planned feature-development practice:
- Favorite / Wishlist
- Quantity
- Category filtering
- Price sorting
- Pagination
- Edit item
- Form validation
- Modal
- API search
- Loading/error states
