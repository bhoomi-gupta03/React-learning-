import React, { useState } from "react";

function ProductList() {
  const [search, setSearch] = useState("");
  const [showInStock, setShowInStock] = useState(false);
  const [cart, setCart] = useState([]);

  const products = [
    { id: 1, name: "Laptop", price: 50000, inStock: true },
    { id: 2, name: "Mouse", price: 1000, inStock: false },
    { id: 3, name: "Keyboard", price: 2000, inStock: true }
  ];

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(search.toLowerCase()) &&
      (!showInStock || product.inStock)
  );

  const addToCart = (product) => {
    const alreadyInCart = cart.some((item) => item.id === product.id);

    if (!alreadyInCart) {
      setCart([...cart, product]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((product) => product.id !== id));
  };

  return (
    <div>
      <h1>Product Search & Cart</h1>

      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search product"
      />

      <label>
        <input
          type="checkbox"
          checked={showInStock}
          onChange={(e) => setShowInStock(e.target.checked)}
        />
        Show only in-stock
      </label>

      <p>Cart: {cart.length} items</p>

      <h2>Cart</h2>

      {cart.map((product) => (
        <div key={product.id}>
          <h3>{product.name}</h3>
          <p>₹{product.price}</p>
          <button onClick={() => removeFromCart(product.id)}>
            Remove
          </button>
        </div>
      ))}

      <h2>Products</h2>

      {filteredProducts.map((product) => (
        <div key={product.id}>
          <h3>{product.name}</h3>
          <p>₹{product.price}</p>

          <button onClick={() => addToCart(product)}>
            Add to Cart
          </button>
        </div>
      ))}
    </div>
  );
}

export default ProductList;
